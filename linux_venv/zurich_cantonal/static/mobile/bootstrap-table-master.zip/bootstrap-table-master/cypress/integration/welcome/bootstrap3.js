require('../../common/welcome')('bootstrap3')
